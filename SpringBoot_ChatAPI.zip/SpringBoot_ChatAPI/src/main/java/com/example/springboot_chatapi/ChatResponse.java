package com.example.springboot_chatapi;

import java.util.List;

public class ChatResponse {

    private List<Choice> choices;

    // getters and setters
    public List<Choice> getChoices() {
        return this.choices;
    }

    public void setChoices(List<Choice> choices) {
        this.choices = choices;
    }

    public static class Choice {
        private Message message;
        private String finish_reason;

        // getters and setters
        public Message getMessage(){
            return this.message;
        }

        public void setMessage(Message message) {
            this.message = message;
        }

        public String getFinish_reason(){
            return this.finish_reason;
        }

        public void setFinish_reason(String finish_reason){
            this.finish_reason = finish_reason;
        }

        private int index;

        // constructors, getters and setters

        public int getIndex() {
            return index;
        }

        public void setIndex(int index) {
            this.index = index;
        }


    }
}
